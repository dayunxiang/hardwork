var pathName = window.location.pathname;
pathName = pathName.substring(0, pathName.substr(1).indexOf('/') + 1);

var pathUrl = 'http://192.168.200.148:8089/water';


